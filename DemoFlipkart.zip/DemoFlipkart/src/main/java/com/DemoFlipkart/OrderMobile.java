package com.DemoFlipkart;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrderMobile {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String baseUrl = "https://www.flipkart.com/";
		driver.get(baseUrl);
		driver.manage().window().maximize();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement cross = wait.until(
		    ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div/div/button")));
		cross.click();
		driver.findElement(By.name("q")).sendKeys("redmi");
		driver.findElement(By.name("q")).sendKeys(Keys.RETURN);
		Thread.sleep(10000);
		List<WebElement> links =  driver.findElements(By.tagName("a"));
//		for (Iterator iterator = links.iterator(); iterator.hasNext();) {
//			WebElement webElement = (WebElement) iterator.next();
//			System.out.println(webElement.getAttribute("href"));
//		}
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]")).findElement(By.tagName("a")).click();		
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs2.get(1));
		String price = driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div[4]/div[1]/div/div[1]")).getText();
		System.out.println("Mobile Price is "+price);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[1]/div[2]/div/ul/li[1]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[1]/div/div[2]/div/div[3]/div[1]/div/button[2]")).click();
		String updatedPrice = driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[1]/div/div[2]/div/div[1]/div[1]/span[2]")).getText();
		System.out.println("Updated price is "+updatedPrice);
	}

}
